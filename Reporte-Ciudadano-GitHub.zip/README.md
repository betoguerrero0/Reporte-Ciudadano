# Reporte Ciudadano

Prototipo frontend responsive para registrar problemas urbanos, guardar reportes localmente y consultar su estado en el mismo navegador.

## Archivos
- `index.html`: estructura de la web.
- `style.css`: estilos responsive.
- `script.js`: validación, LocalStorage, código de seguimiento y preparación del mensaje de WhatsApp.
- `img/tarija-inicio.png`: imagen de inicio proporcionada por la usuaria.

## Cómo abrir
1. Descarga y descomprime `Reporte-Ciudadano.zip`.
2. Abre `index.html` en Chrome.
3. Para que el botón de ubicación funcione con más fiabilidad, sirve la carpeta desde `localhost` (por ejemplo, con la extensión Live Server de VS Code). También puedes escribir la ubicación manualmente.

## Importante sobre WhatsApp
El formulario guarda el reporte y muestra una confirmación en la web. Después intenta abrir `https://wa.me/59172981122` con un mensaje prellenado. Por las restricciones de WhatsApp, una página frontend no puede enviar mensajes silenciosamente ni garantizar el envío sin que el usuario confirme dentro de WhatsApp. Para automatizar el envío real hace falta un backend seguro y una integración autorizada con WhatsApp Business Platform o un proveedor compatible.

## Almacenamiento y privacidad
Los reportes y el perfil se guardan en LocalStorage, solo en ese navegador/dispositivo. No existe una base de datos central ni sincronización institucional. Las fotos no se cargan ni se adjuntan automáticamente. No uses este prototipo para datos sensibles.

## Personalización
El número de contacto está definido en `script.js` como `WHATSAPP_NUMBER` y en el enlace de contacto del `index.html`. Se usa `59172981122` en formato internacional para Bolivia.
